# 抖音小店自动化上货系统

从WSY采集商品，自动处理后上架到抖音小店。

## 快速安装

```bash
# 方式1：直接安装
cd douyin-shop-automation
bash install/install.sh

# 方式2：作为OpenClaw Skill安装
# 复制到 ~/.agents/skills/douyin-shop-automation/
```

## 依赖

- Python 3.8+
- pip3
- Playwright

## 安装后使用

```bash
# 一键执行
dyshop --category "女装" --limit 20 --profit 30

# 分步执行
dyshop-collect --category "女装" --limit 50
dyshop-process --input data/raw/xxx.json --profit 30
dyshop-upload --input data/processed/xxx.json
```

详细文档见 SKILL.md
